import React from 'react'
import Contact from '../components/Contact'
const Home = () => {
  return (
    <div className=''>
      <Contact/>
    </div>
  )
}

export default Home
